package com.Service;

import com.example.repository.BoatRepository;
import com.model.Boat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class BoatService implements BoatServiceInterface {
@Autowired
private BoatRepository boatRepository;

    @Override
    public Boat saveBoat(Boat boat) {
        return null;
    }

    @Override
    public Optional<Boat> getBoatById(int id) {
        return null;
    }

    @Override
    public List<BoatRepository> getAllBoat() {
        return boatRepository.findAll(Sort.by(Sort.Direction.DESC,"id"));

    }

    @Override
    public Boat updateBoat(int id, Boat boat) {

        Boat boatToUpdate= (Boat) boatRepository.findById(id).orElseThrow();
        boatToUpdate.setDate(boat.getDate());
        boatToUpdate.setId(boatToUpdate.getId());
        boatToUpdate.setTypeA(boatToUpdate.getTypeA());
        boatToUpdate.setTypeB(boatToUpdate.getTypeB());
        boatToUpdate.setTypeC(boatToUpdate.getTypeC());
        boatToUpdate.setTypeAScore(boat.getTypeAScore());
        boatToUpdate.setTypeBScore(boatToUpdate.getTypeBScore());
        boatToUpdate.setTypeCScore(boat.getTypeCScore());

        return boatRepository;


    }


    @Override
    public void deleteBoat(int id) {
        boatRepository.deleteById(id);
    }

 }



