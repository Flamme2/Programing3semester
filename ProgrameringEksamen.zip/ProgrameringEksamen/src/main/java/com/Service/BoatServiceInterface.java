package com.Service;

import com.example.repository.BoatRepository;
import com.model.Boat;

import java.util.List;
import java.util.Optional;

public interface BoatServiceInterface {
     Boat saveBoat(Boat boat);
    Optional<Boat> getBoatById(int id);
    List<BoatRepository> getAllBoat();

    Boat updateBoat(int id, Boat boat);

    void deleteBoat(int id);
}

