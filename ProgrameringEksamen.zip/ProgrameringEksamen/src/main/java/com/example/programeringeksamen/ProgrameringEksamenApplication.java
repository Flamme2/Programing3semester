package com.example.programeringeksamen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgrameringEksamenApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProgrameringEksamenApplication.class, args);
    }

}
