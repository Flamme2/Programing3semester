package com.Utilities;

public class Constant {

    public enum BoadType{
        TYPEA,
        TYPEB,
        TYPEC
    }
}
