package com.Utilities;

import com.model.Competitor;

import java.util.Comparator;

public class Scores implements Comparator<Competitor> {
     @Override
     public int compare(Competitor t, Competitor t1) {

          if (t.getPoints() > t1.getPoints())
               return -1;
          else if (t.getPoints() < t1.getPoints())
               return 1;
          else {
               int goalDif = t.getScoredCount() - t.getVictoryCount();
               int goalDif1 = t1.getScoredCount() - t1.getVictoryCount();
               if (goalDif > goalDif1)
                    return -1;
               else if (goalDif < goalDif1)
                    return 1;
               else return 0;

          }
     }
}