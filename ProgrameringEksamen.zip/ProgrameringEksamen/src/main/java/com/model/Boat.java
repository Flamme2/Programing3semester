package com.model;

import jakarta.persistence.*;

import java.util.Date;
@Entity
public class Boat {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private int id;
@ManyToOne

private Competitor typeA;

@ManyToOne
   private Competitor typeB;

@ManyToOne

   private Competitor typeC;

    private int typeAScore;

    private int typeBScore;

    private int typeCScore;
    private Date date;

    public Competitor getTypeA() {
        return typeA;
    }

    public void setTypeA(Competitor typeA) {
        this.typeA = typeA;
    }

    public Competitor getTypeB() {
        return typeB;
    }

    public void setTypeB(Competitor typeB) {
        this.typeB = typeB;
    }

    public Competitor getTypeC() {
        return typeC;
    }

    public void setTypeC(Competitor typeC) {
        this.typeC = typeC;
    }

    public int getTypeAScore() {
        return typeAScore;
    }

    public void setTypeAScore(int typeAScore) {
        this.typeAScore = typeAScore;
    }

    public int getTypeBScore() {
        return typeBScore;
    }

    public void setTypeBScore(int typeBScore) {
        this.typeBScore = typeBScore;
    }

    public int getTypeCScore() {
        return typeCScore;
    }

    public void setTypeCScore(int teamCScore) {
        this.typeCScore = teamCScore;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



}
