package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Competitor extends Manager{
   @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int id;

        private int  Type;
         private int points;

        private int competitionPlayed;

       private int defeatCount;

       private int victoryCount;

        private int scoredCount;

         private int winCount;

         private int drawCount;

         private String name;

         private String Team;

      public int getCompetitionPlayed() {

        return competitionPlayed;
    }

    public int getDefeatCount() {
        return defeatCount;
    }
    public void setDefeatCount(int i) {
        defeatCount=i;

    }

    public int getType() {
        return Type;
    }

    public void setType(int boatType) {
        this.Type = boatType;
    }

    public int competitionPlayed() {
        return competitionPlayed;
    }

    public void setCompetitionPlayed(int i){
        competitionPlayed= i;
    }


    public int getScoredCount() {
        return scoredCount;
    }

    public void setScoredCount(int i){
        scoredCount = i;
    }

    public int getVictoryCount(){
          return victoryCount;
    }

    public void setVictoryCount(int i){
          victoryCount=i;
    }

    public int getWinCount() {
        return winCount;
    }

    public void setWinCount(int i) {
        winCount =i;
    }

    public int getDrawCount() {
        return drawCount;
    }
    public void setDrawCount(int i){
        drawCount = i;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;

    }


    public int getPoints() {
        return points;
    }

    public void setPoints(int i){
        points = i;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public String getTeam() {
        return Team;
    }

    public void setTeam(String team) {
        Team = team;
    }
}







