package com.Controller;

import com.Service.BoatService;
import com.example.repository.BoatRepository;
import com.model.Boat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/boat")
@CrossOrigin("http://localhost:3000")
public class BoatController {

    @Autowired
    private BoatService boatService;


    @PostMapping("/boat")
    public Boat saveboat(@RequestBody Boat boat){
        return boatService.saveBoat(boat);
    }

    @GetMapping("/")
    public List<BoatRepository> getAllBoat(){
        return boatService.getAllBoat();
    }

    @GetMapping("boat/{id}")
    public Optional<Boat> getBoatById(@PathVariable int id){
        return boatService.getBoatById(id);
    }

    @PutMapping("/boat{id}")
    public Boat updateSailboat(@PathVariable int id, @RequestBody Boat boat){
        return boatService.updateBoat(id,boat);
    }

    @DeleteMapping("/boat{id}")
    public void deleteSailboat(@PathVariable int id){
        boatService.deleteBoat(id);
    }

    }
