package com.Controller;

import com.Exception.CompetitorNotFoundException;
import com.example.repository.CompetitorRepository;
import com.model.Competitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
    @CrossOrigin("http://localhost:3000")
    public class CompetitorController {

    @Autowired
    private CompetitorRepository competitorRepository;

    @PostMapping("/competitor")
    Competitor newCompetitor(@RequestBody Competitor newCompetitor) {
        return competitorRepository.save(newCompetitor);
    }

    @GetMapping("/competitor")
    List<Competitor> getAllCompetitor() {
        return competitorRepository.findAll();
    }

    @GetMapping("/competitor/{id}")
    Competitor getCompetitorById(@PathVariable int id) {
        return competitorRepository.findById(id)
                .orElseThrow(() -> new CompetitorNotFoundException(id));
    }
    @PutMapping("/competitor/{id}")
    Competitor updateCompetitor(@RequestBody Competitor newCompetitor, @PathVariable int id) {
        return competitorRepository.findById(id)
                .map(competitor ->  {
                    competitor.setName(newCompetitor.getName());
                    competitor.setType(newCompetitor.getType());
                    competitor.setPoints(newCompetitor.getPoints());
                    competitor.setId(newCompetitor.getId());
                    competitor.setCompetitionPlayed(newCompetitor.getCompetitionPlayed());
                    competitor.setDefeatCount(newCompetitor.getDefeatCount());
                    competitor.setVictoryCount(newCompetitor.getVictoryCount());
                    competitor.setScoredCount(newCompetitor.getScoredCount());
                    competitor.setWinCount(newCompetitor.getWinCount());
                    competitor.setDrawCount(newCompetitor.getDrawCount());
                    competitor.setTeam(newCompetitor.getTeam());
                    competitor.setLocation(newCompetitor.getLocation());
                    return competitorRepository.save(competitor);
                }).orElseThrow(() -> new CompetitorNotFoundException(id));
    }
    @DeleteMapping("/competitor/{id}")
    String deleteCompetitor(@PathVariable int id) {
        if (!competitorRepository.existsById(id)) {
            throw new CompetitorNotFoundException(id);
        }
        competitorRepository.deleteById(id);
        return "competitor with id " + id + " has been deleted success.";


    }
}










