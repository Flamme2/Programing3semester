package com.Exception;

public class CompetitorNotFoundException extends RuntimeException{
    public CompetitorNotFoundException(int id){
        super("Could not found the competitor with id "+ id);
    }
}
