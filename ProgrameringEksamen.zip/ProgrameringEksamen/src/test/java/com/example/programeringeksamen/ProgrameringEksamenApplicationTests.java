package com.example.programeringeksamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrameringEksamenApplicationTests {

    @Test
    void contextLoads() {
    }

}
